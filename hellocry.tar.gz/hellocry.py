print('hellocry')

